<?php
include('../common/config.php');
session_start();
$order_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if (!$order_id) {
    die("Invalid Order ID");
}

// Update order status via AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $status = $_POST['status'];
    $stmt = $conn->prepare("UPDATE orders SET status=? WHERE id=?");
    $stmt->bind_param("si", $status, $order_id);
    $stmt->execute();
    echo json_encode(['success' => true]);
    exit;
}

// Fetch order data
$order = $conn->query("SELECT o.*, u.name, u.phone, u.email FROM orders o JOIN users u ON o.user_id = u.id WHERE o.id = $order_id")->fetch_assoc();
$items = $conn->query("SELECT p.name, p.image, oi.quantity, oi.price FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = $order_id");

include('./common/header.php');
include('./common/sidebar.php');
?><main class="p-4 ml-16 select-none overflow-hidden">
  <h2 class="text-xl font-bold mb-4">Order #<?php echo $order_id; ?> Details</h2>  <div class="bg-white shadow rounded p-4 mb-4">
    <h3 class="font-semibold mb-2">Customer Info</h3>
    <p><strong>Name:</strong> <?php echo htmlspecialchars($order['name']); ?></p>
    <p><strong>Phone:</strong> <?php echo htmlspecialchars($order['phone']); ?></p>
    <p><strong>Email:</strong> <?php echo htmlspecialchars($order['email']); ?></p>
    <p><strong>Order Date:</strong> <?php echo date('d M Y, h:i A', strtotime($order['created_at'])); ?></p>
    <p><strong>Status:</strong>
      <select id="statusSelect" class="border p-1 rounded">
        <option value="Placed" <?php if($order['status'] === 'Placed') echo 'selected'; ?>>Placed</option>
        <option value="Dispatched" <?php if($order['status'] === 'Dispatched') echo 'selected'; ?>>Dispatched</option>
        <option value="Delivered" <?php if($order['status'] === 'Delivered') echo 'selected'; ?>>Delivered</option>
        <option value="Cancelled" <?php if($order['status'] === 'Cancelled') echo 'selected'; ?>>Cancelled</option>
      </select>
    </p>
  </div>  <div class="bg-white shadow rounded p-4">
    <h3 class="font-semibold mb-3">Ordered Items</h3>
    <?php while ($item = $items->fetch_assoc()): ?>
      <div class="flex items-center justify-between border-b py-2">
        <div class="flex items-center space-x-3">
          <img src="../images/<?php echo htmlspecialchars($item['image']); ?>" class="w-16 h-16 object-cover rounded">
          <div>
            <p class="font-medium"><?php echo htmlspecialchars($item['name']); ?></p>
            <p>Qty: <?php echo $item['quantity']; ?></p>
          </div>
        </div>
        <div class="text-right">
          <p class="text-lg font-semibold text-green-600">₹<?php echo number_format($item['price'] * $item['quantity']); ?></p>
        </div>
      </div>
    <?php endwhile; ?>
    <div class="text-right font-bold mt-4">Total: ₹<?php echo number_format($order['total_amount']); ?></div>
  </div>
</main><script>
document.getElementById('statusSelect').addEventListener('change', function () {
  const status = this.value;
  fetch(window.location.href, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'status=' + encodeURIComponent(status)
  })
  .then(res => res.json())
  .then(data => {
    if (data.success) alert('Status updated successfully!');
  });
});
</script><?php include('./common/bottom.php'); ?>