<?php
include('../common/config.php');
session_start();

$admin_id = 1;
$success = false;
$error = '';

// Handle password update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $current = trim($_POST['current_password'] ?? '');
    $new = trim($_POST['new_password'] ?? '');

    if ($username && $current && $new) {
        $stmt = $conn->prepare("SELECT * FROM admin WHERE id = ?");
        $stmt->bind_param("i", $admin_id);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($res && $res->num_rows === 1) {
            $admin_data = $res->fetch_assoc();

            // If using plain text (not recommended), match directly:
            if ($admin_data['password'] === $current) {
                $update = $conn->prepare("UPDATE admin SET username = ?, password = ? WHERE id = ?");
                $update->bind_param("ssi", $username, $new, $admin_id);
                $update->execute();
                $success = true;
            } else {
                $error = "Incorrect current password.";
            }

            // Recommended: use hashed password instead
            // if (password_verify($current, $admin_data['password'])) {
            //     $new_hashed = password_hash($new, PASSWORD_DEFAULT);
            //     $update = $conn->prepare("UPDATE admin SET username = ?, password = ? WHERE id = ?");
            //     $update->bind_param("ssi", $username, $new_hashed, $admin_id);
            //     $update->execute();
            //     $success = true;
            // } else {
            //     $error = "Incorrect current password.";
            // }
        } else {
            $error = "Admin not found.";
        }
    } else {
        $error = "All fields are required.";
    }
}

// Fetch admin info
$admin = $conn->query("SELECT * FROM admin WHERE id = 1")->fetch_assoc();

include('./common/header.php');
include('./common/sidebar.php');
?>

<main class="p-4 ml-16 select-none overflow-hidden">
  <h2 class="text-xl font-bold mb-4">Admin Settings</h2>

  <?php if ($success): ?>
    <div class="mb-4 p-2 bg-green-100 text-green-800 rounded">Updated successfully!</div>
  <?php elseif (!empty($error)): ?>
    <div class="mb-4 p-2 bg-red-100 text-red-700 rounded"><?php echo htmlspecialchars($error); ?></div>
  <?php endif; ?>

  <form method="POST" class="space-y-4 max-w-md">
    <div>
      <label class="block mb-1 font-medium">Username</label>
      <input type="text" name="username" value="<?php echo htmlspecialchars($admin['username'] ?? ''); ?>" class="w-full border p-2 rounded" required>
    </div>
    <div>
      <label class="block mb-1 font-medium">Current Password</label>
      <input type="password" name="current_password" class="w-full border p-2 rounded" required>
    </div>
    <div>
      <label class="block mb-1 font-medium">New Password</label>
      <input type="password" name="new_password" class="w-full border p-2 rounded" required>
    </div>
    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Update</button>
  </form>
</main>

<script>
  document.addEventListener("contextmenu", e => e.preventDefault());
  document.addEventListener("selectstart", e => e.preventDefault());
  document.addEventListener("keydown", function(e) {
    if ((e.ctrlKey && (e.key === '+' || e.key === '-' || e.key === '0'))) {
      e.preventDefault();
    }
  });
</script>

<?php include('./common/bottom.php'); ?>