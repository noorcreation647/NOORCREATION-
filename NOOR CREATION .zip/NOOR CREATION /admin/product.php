<?php
$pageTitle = 'Products';
include('common/header.php');

// Get category filter if exists
$categoryFilter = isset($_GET['category']) ? "WHERE cat_id = " . intval($_GET['category']) : '';

// Get sort filter
$sort = 'ORDER BY created_at DESC';
if (isset($_GET['sort'])) {
    switch ($_GET['sort']) {
        case 'price_low':
            $sort = 'ORDER BY price ASC';
            break;
        case 'price_high':
            $sort = 'ORDER BY price DESC';
            break;
        case 'new':
        default:
            $sort = 'ORDER BY created_at DESC';
            break;
    }
}

// Fetch products
$products = $conn->query("SELECT * FROM products $categoryFilter $sort");

// Fetch categories for filter
$categories = $conn->query("SELECT * FROM categories");
?>

<div class="p-4 min-h-[calc(100vh-140px)]">
    <!-- Filters -->
    <div class="bg-white rounded-lg shadow-sm p-4 mb-6">
        <div class="flex justify-between items-center mb-4">
            <h2 class="text-lg font-bold">Products</h2>
            <div class="flex items-center gap-2">
                <span class="text-sm">Sort:</span>
                <select id="sortSelect" class="border rounded px-2 py-1 text-sm">
                    <option value="new" <?= (!isset($_GET['sort']) || $_GET['sort'] == 'new') ? 'selected' : '' ?>>Newest</option>
                    <option value="price_low" <?= (isset($_GET['sort']) && $_GET['sort'] == 'price_low') ? 'selected' : '' ?>>Price: Low to High</option>
                    <option value="price_high" <?= (isset($_GET['sort']) && $_GET['sort'] == 'price_high') ? 'selected' : '' ?>>Price: High to Low</option>
                </select>
            </div>
        </div>
        
        <div class="flex overflow-x-auto gap-2 pb-2">
            <a href="product.php" class="shrink-0 px-3 py-1 rounded-full bg-gray-100 text-gray-700 text-sm">All</a>
            <?php while($category = $categories->fetch_assoc()): ?>
            <a href="product.php?category=<?= $category['id'] ?>" class="shrink-0 px-3 py-1 rounded-full bg-gray-100 text-gray-700 text-sm"><?= htmlspecialchars($category['name']) ?></a>
            <?php endwhile; ?>
        </div>
    </div>
    
    <!-- Products Grid -->
    <div class="product-grid">
        <?php if ($products->num_rows > 0): ?>
            <?php while($product = $products->fetch_assoc()): ?>
            <div class="bg-white rounded-lg shadow-sm overflow-hidden border border-gray-100">
                <div class="bg-gray-200 border-2 border-dashed w-full h-40"></div>
                <div class="p-3">
                    <h4 class="font-medium text-gray-800 truncate"><?= htmlspecialchars($product['name']) ?></h4>
                    <p class="text-primary font-bold mt-1">₹<?= number_format($product['price']) ?></p>
                    <div class="flex justify-between mt-3">
                        <a href="product_detail.php?id=<?= $product['id'] ?>" class="text-xs bg-gray-100 hover:bg-gray-200 py-1 px-2 rounded">View</a>
                        <button class="text-xs bg-primary text-white hover:bg-purple-700 py-1 px-2 rounded add-to-cart" data-id="<?= $product['id'] ?>">Add to Cart</button>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-span-4 text-center py-10">
                <p class="text-gray-500">No products found</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Sort change handler
        document.getElementById('sortSelect').addEventListener('change', function() {
            const sort = this.value;
            window.location.href = `product.php?sort=${sort}`;
        });
        
        // Add to cart functionality
        document.querySelectorAll('.add-to-cart').forEach(button => {
            button.addEventListener('click', function() {
                const productId = this.getAttribute('data-id');
                showLoading();
                
                // AJAX request to add to cart
                ajaxRequest('add_to_cart.php', 'POST', `product_id=${productId}`, function(response) {
                    hideLoading();
                    if (response.success) {
                        showToast('Product added to cart');
                        // Update cart count
                        const cartCount = document.querySelector('a[href="cart.php"] span');
                        if (cartCount) {
                            cartCount.textContent = response.cart_count;
                        } else {
                            // Create cart count if doesn't exist
                            const cartLink = document.querySelector('a[href="cart.php"]');
                            if (cartLink) {
                                const countSpan = document.createElement('span');
                                countSpan.className = 'absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center';
                                countSpan.textContent = response.cart_count;
                                cartLink.appendChild(countSpan);
                            }
                        }
                    } else {
                        showToast(response.message, 'error');
                    }
                });
            });
        });
    });
</script>

<?php include('common/bottom.php'); ?>