<?php
include('../common/config.php');
session_start();

// Handle user block/delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM users WHERE id=$id");
    header("Location: user.php");
    exit;
}

// Fetch users
$users = $conn->query("SELECT * FROM users ORDER BY id DESC");

include('./common/header.php');
include('./common/sidebar.php');
?><main class="p-4 ml-16 select-none overflow-hidden">
  <h2 class="text-xl font-bold mb-4">Registered Users</h2>  <div class="overflow-x-auto">
    <table class="min-w-full text-sm border">
      <thead>
        <tr class="bg-gray-100">
          <th class="py-2 px-4 border">ID</th>
          <th class="py-2 px-4 border">Name</th>
          <th class="py-2 px-4 border">Email</th>
          <th class="py-2 px-4 border">Phone</th>
          <th class="py-2 px-4 border">Registered</th>
          <th class="py-2 px-4 border">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($user = $users->fetch_assoc()): ?>
        <tr class="border-t">
          <td class="py-2 px-4 border"><?php echo $user['id']; ?></td>
          <td class="py-2 px-4 border"><?php echo htmlspecialchars($user['name']); ?></td>
          <td class="py-2 px-4 border"><?php echo htmlspecialchars($user['email']); ?></td>
          <td class="py-2 px-4 border"><?php echo htmlspecialchars($user['phone']); ?></td>
          <td class="py-2 px-4 border"><?php echo date('d M Y', strtotime($user['created_at'])); ?></td>
          <td class="py-2 px-4 border">
            <a href="?delete=<?php echo $user['id']; ?>" onclick="return confirm('Are you sure to delete this user?')" class="text-red-600 hover:underline">Delete</a>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</main><script>
  document.addEventListener("contextmenu", e => e.preventDefault());
  document.addEventListener("selectstart", e => e.preventDefault());
  document.addEventListener("keydown", function(e) {
    if ((e.ctrlKey && e.key === '+') || (e.ctrlKey && e.key === '-') || (e.ctrlKey && e.key === '0')) {
      e.preventDefault();
    }
  });
</script><?php include('./common/bottom.php'); ?>