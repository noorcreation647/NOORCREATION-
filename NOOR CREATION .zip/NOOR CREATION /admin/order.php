<?php
$pageTitle = 'My Orders';
include('common/header.php');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$userId = $_SESSION['user_id'];

// Fetch active orders (placed, dispatched)
$activeOrders = $conn->query("
    SELECT o.id, o.total_amount, o.status, o.created_at, 
           COUNT(oi.id) AS item_count
    FROM orders o
    JOIN order_items oi ON o.id = oi.order_id
    WHERE o.user_id = $userId AND o.status IN ('placed', 'dispatched')
    GROUP BY o.id
    ORDER BY o.created_at DESC
");

// Fetch order history (delivered, cancelled)
$orderHistory = $conn->query("
    SELECT o.id, o.total_amount, o.status, o.created_at, 
           COUNT(oi.id) AS item_count
    FROM orders o
    JOIN order_items oi ON o.id = oi.order_id
    WHERE o.user_id = $userId AND o.status IN ('delivered', 'cancelled')
    GROUP BY o.id
    ORDER BY o.created_at DESC
");

// Function to get status progress
function getStatusProgress($status) {
    $steps = [
        'placed' => ['active' => true, 'completed' => false],
        'dispatched' => ['active' => false, 'completed' => false],
        'delivered' => ['active' => false, 'completed' => false]
    ];
    
    if ($status === 'dispatched') {
        $steps['placed']['completed'] = true;
        $steps['dispatched']['active'] = true;
    } elseif ($status === 'delivered') {
        $steps['placed']['completed'] = true;
        $steps['dispatched']['completed'] = true;
        $steps['delivered']['active'] = true;
    } else {
        $steps['placed']['active'] = true;
    }
    
    return $steps;
}
?>

<div class="min-h-[calc(100vh-140px)] p-4">
    <h1 class="text-xl font-bold mb-6">My Orders</h1>
    
    <div class="flex border-b mb-6">
        <button id="activeTab" class="flex-1 py-3 font-medium text-center border-b-2 border-primary text-primary">Active Orders</button>
        <button id="historyTab" class="flex-1 py-3 font-medium text-center text-gray-500">Order History</button>
    </div>
    
    <!-- Active Orders -->
    <div id="activeOrders">
        <?php if ($activeOrders->num_rows > 0): ?>
            <div class="space-y-4">
                <?php while($order = $activeOrders->fetch_assoc()): ?>
                <?php $statusProgress = getStatusProgress($order['status']); ?>
                <div class="bg-white rounded-lg shadow-sm overflow-hidden order-card <?= $order['status'] ?>">
                    <div class="p-4 border-b">
                        <div class="flex justify-between items-center">
                            <div>
                                <p class="text-sm text-gray-500">Order #<?= $order['id'] ?></p>
                                <p class="font-medium">₹<?= number_format($order['total_amount']) ?></p>
                            </div>
                            <span class="px-3 py-1 rounded-full text-xs 
                                <?= $order['status'] === 'placed' ? 'bg-yellow-100 text-yellow-800' : '' ?>
                                <?= $order['status'] === 'dispatched' ? 'bg-blue-100 text-blue-800' : '' ?>
                            ">
                                <?= ucfirst($order['status']) ?>
                            </span>
                        </div>
                        <p class="text-sm text-gray-500 mt-1"><?= date('d M Y, h:i A', strtotime($order['created_at'])) ?></p>
                    </div>
                    
                    <div class="p-4">
                        <!-- Progress Tracker -->
                        <div class="progress-tracker flex justify-between mb-4">
                            <div class="step <?= $statusProgress['placed']['active'] || $statusProgress['placed']['completed'] ? 'active' : '' ?>">
                                <div class="step-icon w-10 h-10 rounded-full border-2 border-gray-300 bg-white flex items-center justify-center mx-auto">
                                    <i class="fas fa-shopping-bag text-sm"></i>
                                </div>
                                <div class="step-label mt-2 text-xs font-medium">Placed</div>
                            </div>
                            
                            <div class="step <?= $statusProgress['dispatched']['active'] || $statusProgress['dispatched']['completed'] ? 'active' : '' ?>">
                                <div class="step-icon w-10 h-10 rounded-full border-2 border-gray-300 bg-white flex items-center justify-center mx-auto">
                                    <i class="fas fa-shipping-fast text-sm"></i>
                                </div>
                                <div class="step-label mt-2 text-xs font-medium">Dispatched</div>
                            </div>
                            
                            <div class="step <?= $statusProgress['delivered']['active'] ? 'active' : '' ?>">
                                <div class="step-icon w-10 h-10 rounded-full border-2 border-gray-300 bg-white flex items-center justify-center mx-auto">
                                    <i class="fas fa-check-circle text-sm"></i>
                                </div>
                                <div class="step-label mt-2 text-xs font-medium">Delivered</div>
                            </div>
                        </div>
                        
                        <div class="flex justify-between items-center">
                            <p class="text-sm"><?= $order['item_count'] ?> item<?= $order['item_count'] > 1 ? 's' : '' ?></p>
                            <a href="order_detail.php?id=<?= $order['id'] ?>" class="text-primary text-sm font-medium">View Details</a>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <div class="text-center py-10">
                <div class="bg-gray-200 border-2 border-dashed rounded-xl w-16 h-16 mx-auto mb-4"></div>
                <p class="text-gray-600">You don't have any active orders</p>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Order History -->
    <div id="orderHistory" class="hidden">
        <?php if ($orderHistory->num_rows > 0): ?>
            <div class="space-y-4">
                <?php while($order = $orderHistory->fetch_assoc()): ?>
                <div class="bg-white rounded-lg shadow-sm overflow-hidden order-card <?= $order['status'] ?>">
                    <div class="p-4 border-b">
                        <div class="flex justify-between items-center">
                            <div>
                                <p class="text-sm text-gray-500">Order #<?= $order['id'] ?></p>
                                <p class="font-medium">₹<?= number_format($order['total_amount']) ?></p>
                            </div>
                            <span class="px-3 py-1 rounded-full text-xs 
                                <?= $order['status'] === 'delivered' ? 'bg-green-100 text-green-800' : '' ?>
                                <?= $order['status'] === 'cancelled' ? 'bg-red-100 text-red-800' : '' ?>
                            ">
                                <?= ucfirst($order['status']) ?>
                            </span>
                        </div>
                        <p class="text-sm text-gray-500 mt-1"><?= date('d M Y, h:i A', strtotime($order['created_at'])) ?></p>
                    </div>
                    
                    <div class="p-4">
                        <div class="flex justify-between items-center">
                            <p class="text-sm"><?= $order['item_count'] ?> item<?= $order['item_count'] > 1 ? 's' : '' ?></p>
                            <a href="order_detail.php?id=<?= $order['id'] ?>" class="text-primary text-sm font-medium">View Details</a>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <div class="text-center py-10">
                <div class="bg-gray-200 border-2 border-dashed rounded-xl w-16 h-16 mx-auto mb-4"></div>
                <p class="text-gray-600">You don't have any order history</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const activeTab = document.getElementById('activeTab');
        const historyTab = document.getElementById('historyTab');
        const activeOrders = document.getElementById('activeOrders');
        const orderHistory = document.getElementById('orderHistory');
        
        activeTab.addEventListener('click', () => {
            activeOrders.classList.remove('hidden');
            orderHistory.classList.add('hidden');
            activeTab.classList.add('border-b-2', 'border-primary', 'text-primary');
            historyTab.classList.remove('border-b-2', 'border-primary', 'text-primary');
            historyTab.classList.add('text-gray-500');
        });
        
        historyTab.addEventListener('click', () => {
            orderHistory.classList.remove('hidden');
            activeOrders.classList.add('hidden');
            historyTab.classList.add('border-b-2', 'border-primary', 'text-primary');
            activeTab.classList.remove('border-b-2', 'border-primary', 'text-primary');
            activeTab.classList.add('text-gray-500');
        });
    });
</script>

<?php include('common/bottom.php'); ?>