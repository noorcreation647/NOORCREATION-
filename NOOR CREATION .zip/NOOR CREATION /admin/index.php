<?php
$pageTitle = 'Home';
include('common/header.php');

// Fetch categories
$categories = $conn->query("SELECT * FROM categories LIMIT 8");

// Fetch featured products
$products = $conn->query("SELECT * FROM products ORDER BY created_at DESC LIMIT 8");
?>

<div class="p-4 min-h-[calc(100vh-140px)]">
    <!-- Hero Banner -->
    <div class="rounded-xl overflow-hidden mb-6 h-48 relative">
        <div class="absolute inset-0 bg-gradient-to-r from-purple-500 to-indigo-600 flex items-center justify-center">
            <div class="text-center p-4">
                <h2 class="text-white text-2xl font-bold mb-2">Summer Collection</h2>
                <p class="text-white mb-4">Up to 50% off on new arrivals</p>
                <button class="bg-white text-primary px-6 py-2 rounded-full font-medium">Shop Now</button>
            </div>
        </div>
    </div>
    
    <!-- Categories -->
    <div class="mb-8">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-lg font-bold">Categories</h3>
            <a href="product.php" class="text-primary text-sm">View All</a>
        </div>
        <div class="flex overflow-x-auto gap-4 pb-2 -mx-1 px-1">
            <?php while($category = $categories->fetch_assoc()): ?>
            <a href="product.php?category=<?= $category['id'] ?>" class="flex flex-col items-center shrink-0">
                <div class="bg-gray-200 border-2 border-dashed rounded-xl w-16 h-16 flex items-center justify-center mb-2"></div>
                <span class="text-sm"><?= htmlspecialchars($category['name']) ?></span>
            </a>
            <?php endwhile; ?>
        </div>
    </div>
    
    <!-- Featured Products -->
    <div>
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-lg font-bold">Featured Products</h3>
            <a href="product.php" class="text-primary text-sm">View All</a>
        </div>
        <div class="product-grid">
            <?php while($product = $products->fetch_assoc()): ?>
            <div class="bg-white rounded-lg shadow-sm overflow-hidden border border-gray-100">
                <div class="bg-gray-200 border-2 border-dashed w-full h-32"></div>
                <div class="p-3">
                    <h4 class="font-medium text-gray-800 truncate"><?= htmlspecialchars($product['name']) ?></h4>
                    <p class="text-primary font-bold mt-1">₹<?= number_format($product['price']) ?></p>
                    <div class="flex justify-between mt-3">
                        <a href="product_detail.php?id=<?= $product['id'] ?>" class="text-xs bg-gray-100 hover:bg-gray-200 py-1 px-2 rounded">View</a>
                        <button class="text-xs bg-primary text-white hover:bg-purple-700 py-1 px-2 rounded add-to-cart" data-id="<?= $product['id'] ?>">Add to Cart</button>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Add to cart functionality
        document.querySelectorAll('.add-to-cart').forEach(button => {
            button.addEventListener('click', function() {
                const productId = this.getAttribute('data-id');
                showLoading();
                
                // AJAX request to add to cart
                ajaxRequest('add_to_cart.php', 'POST', `product_id=${productId}`, function(response) {
                    hideLoading();
                    if (response.success) {
                        showToast('Product added to cart');
                        // Update cart count
                        const cartCount = document.querySelector('a[href="cart.php"] span');
                        if (cartCount) {
                            cartCount.textContent = response.cart_count;
                        } else {
                            // Create cart count if doesn't exist
                            const cartLink = document.querySelector('a[href="cart.php"]');
                            if (cartLink) {
                                const countSpan = document.createElement('span');
                                countSpan.className = 'absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center';
                                countSpan.textContent = response.cart_count;
                                cartLink.appendChild(countSpan);
                            }
                        }
                    } else {
                        showToast(response.message, 'error');
                    }
                });
            });
        });
    });
</script>

<?php include('common/bottom.php'); ?>