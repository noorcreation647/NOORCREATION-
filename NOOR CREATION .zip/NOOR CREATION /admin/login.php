<?php
$pageTitle = 'Login';
include('common/header.php');

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['login'])) {
        // Login logic
        $email = $_POST['email'];
        $password = $_POST['password'];
        
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['user_email'] = $user['email'];
                header("Location: index.php");
                exit();
            } else {
                $loginError = "Invalid email or password";
            }
        } else {
            $loginError = "Invalid email or password";
        }
    } elseif (isset($_POST['signup'])) {
        // Signup logic
        $name = $_POST['name'];
        $phone = $_POST['phone'];
        $email = $_POST['signup_email'];
        $password = $_POST['signup_password'];
        
        // Check if email exists
        $check = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $check->bind_param("s", $email);
        $check->execute();
        $check->store_result();
        
        if ($check->num_rows > 0) {
            $signupError = "Email already registered";
        } else {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (name, phone, email, password) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $name, $phone, $email, $hashedPassword);
            
            if ($stmt->execute()) {
                $_SESSION['user_id'] = $stmt->insert_id;
                $_SESSION['user_name'] = $name;
                $_SESSION['user_email'] = $email;
                header("Location: index.php");
                exit();
            } else {
                $signupError = "Error creating account. Please try again.";
            }
        }
    }
}
?>

<div class="min-h-[calc(100vh-140px)] p-4 flex items-center justify-center">
    <div class="w-full max-w-md">
        <div class="bg-white rounded-xl shadow-lg p-6">
            <div class="flex border-b mb-6">
                <button id="loginTab" class="flex-1 py-3 font-medium text-center border-b-2 border-primary text-primary">Login</button>
                <button id="signupTab" class="flex-1 py-3 font-medium text-center text-gray-500">Sign Up</button>
            </div>
            
            <!-- Login Form -->
            <form id="loginForm" method="POST" class="mb-0">
                <input type="hidden" name="login" value="1">
                
                <?php if (isset($loginError)): ?>
                <div class="mb-4 p-3 bg-red-100 text-red-700 rounded-md">
                    <?php echo $loginError; ?>
                </div>
                <?php endif; ?>
                
                <div class="mb-4">
                    <label class="block text-gray-700 mb-2">Email</label>
                    <input type="email" name="email" required class="w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary">
                </div>
                
                <div class="mb-6">
                    <label class="block text-gray-700 mb-2">Password</label>
                    <input type="password" name="password" required class="w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary">
                </div>
                
                <button type="submit" class="w-full bg-primary text-white py-3 rounded-lg font-medium hover:bg-purple-700 transition">Login</button>
            </form>
            
            <!-- Signup Form -->
            <form id="signupForm" method="POST" class="hidden">
                <input type="hidden" name="signup" value="1">
                
                <?php if (isset($signupError)): ?>
                <div class="mb-4 p-3 bg-red-100 text-red-700 rounded-md">
                    <?php echo $signupError; ?>
                </div>
                <?php endif; ?>
                
                <div class="mb-4">
                    <label class="block text-gray-700 mb-2">Full Name</label>
                    <input type="text" name="name" required class="w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary">
                </div>
                
                <div class="mb-4">
                    <label class="block text-gray-700 mb-2">Phone</label>
                    <input type="tel" name="phone" required class="w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary">
                </div>
                
                <div class="mb-4">
                    <label class="block text-gray-700 mb-2">Email</label>
                    <input type="email" name="signup_email" required class="w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary">
                </div>
                
                <div class="mb-6">
                    <label class="block text-gray-700 mb-2">Password</label>
                    <input type="password" name="signup_password" required class="w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary">
                </div>
                
                <button type="submit" class="w-full bg-primary text-white py-3 rounded-lg font-medium hover:bg-purple-700 transition">Create Account</button>
            </form>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const loginTab = document.getElementById('loginTab');
        const signupTab = document.getElementById('signupTab');
        const loginForm = document.getElementById('loginForm');
        const signupForm = document.getElementById('signupForm');
        
        loginTab.addEventListener('click', () => {
            loginForm.classList.remove('hidden');
            signupForm.classList.add('hidden');
            loginTab.classList.add('border-b-2', 'border-primary', 'text-primary');
            signupTab.classList.remove('border-b-2', 'border-primary', 'text-primary');
            signupTab.classList.add('text-gray-500');
        });
        
        signupTab.addEventListener('click', () => {
            signupForm.classList.remove('hidden');
            loginForm.classList.add('hidden');
            signupTab.classList.add('border-b-2', 'border-primary', 'text-primary');
            loginTab.classList.remove('border-b-2', 'border-primary', 'text-primary');
            loginTab.classList.add('text-gray-500');
        });
    });
</script>

<?php include('common/bottom.php'); ?>