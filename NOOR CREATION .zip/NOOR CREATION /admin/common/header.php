<?php
// common/header.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>NOOR CREATION Admin</title>
  
  <!-- Font Awesome for icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />

  <!-- Tailwind CSS CDN -->
  <script src="https://cdn.tailwindcss.com"></script>

  <!-- Disable zoom, right-click, text select -->
  <script>
    document.addEventListener("contextmenu", e => e.preventDefault());
    document.addEventListener("selectstart", e => e.preventDefault());
    document.addEventListener("keydown", function(e) {
      if ((e.ctrlKey && (e.key === '+' || e.key === '-' || e.key === '0'))) {
        e.preventDefault();
      }
    });
  </script>
</head>
<body class="bg-gray-100 text-gray-900 select-none">
  <!-- Top Header -->
  <header class="fixed top-0 left-0 right-0 h-14 bg-white shadow flex items-center justify-between px-4 z-50">
    <div class="text-lg font-bold text-blue-600">
      <i class="fas fa-store text-blue-500 mr-1"></i> NOOR CREATION
    </div>
    <div class="text-sm">
      <a href="../index.php" target="_blank" class="text-blue-500 hover:underline">
        Visit Site <i class="fas fa-arrow-up-right-from-square text-xs ml-1"></i>
      </a>
    </div>
  </header>

  <!-- Space below header to prevent overlap -->
  <div class="h-14"></div>