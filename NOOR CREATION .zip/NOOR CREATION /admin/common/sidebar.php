<?php
// common/sidebar.php
?><aside class="fixed top-14 left-0 w-48 h-[calc(100vh-3.5rem)] bg-white shadow-md border-r z-40">
  <nav class="flex flex-col p-4 space-y-2">
    <a href="../admin/index.php" class="text-sm hover:bg-gray-100 p-2 rounded flex items-center gap-2">
      <i class="fas fa-home"></i> Dashboard
    </a>
    <a href="../admin/category.php" class="text-sm hover:bg-gray-100 p-2 rounded flex items-center gap-2">
      <i class="fas fa-th-large"></i> Categories
    </a>
    <a href="../admin/product.php" class="text-sm hover:bg-gray-100 p-2 rounded flex items-center gap-2">
      <i class="fas fa-box"></i> Products
    </a>
    <a href="../admin/order.php" class="text-sm hover:bg-gray-100 p-2 rounded flex items-center gap-2">
      <i class="fas fa-shopping-cart"></i> Orders
    </a>
    <a href="../admin/user.php" class="text-sm hover:bg-gray-100 p-2 rounded flex items-center gap-2">
      <i class="fas fa-users"></i> Users
    </a>
    <a href="../admin/setting.php" class="text-sm hover:bg-gray-100 p-2 rounded flex items-center gap-2">
      <i class="fas fa-cog"></i> Settings
    </a>
    <a href="../login.php" class="text-sm hover:bg-gray-100 p-2 rounded flex items-center gap-2 text-red-600">
      <i class="fas fa-sign-out-alt"></i> Logout
    </a>
  </nav>
</aside>
<div class="w-48"></div> <!-- Sidebar spacer -->