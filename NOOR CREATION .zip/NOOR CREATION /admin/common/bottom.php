<?php
// common/bottom.php
?>
<!-- Bottom fixed nav for mobile-style admin panel (optional) -->
<footer class="fixed bottom-0 left-0 w-full h-12 bg-white border-t flex justify-around items-center shadow-inner z-40">
  <a href="../admin/index.php" class="flex flex-col items-center text-xs text-gray-600 hover:text-blue-600">
    <i class="fas fa-home text-lg"></i>
    Home
  </a>
  <a href="../admin/order.php" class="flex flex-col items-center text-xs text-gray-600 hover:text-blue-600">
    <i class="fas fa-box text-lg"></i>
    Orders
  </a>
  <a href="../admin/user.php" class="flex flex-col items-center text-xs text-gray-600 hover:text-blue-600">
    <i class="fas fa-users text-lg"></i>
    Users
  </a>
  <a href="../admin/setting.php" class="flex flex-col items-center text-xs text-gray-600 hover:text-blue-600">
    <i class="fas fa-cog text-lg"></i>
    Settings
  </a>
</footer>

</body>
</html>