<?php
include('../common/config.php');
session_start();

// Disable right-click, text selection, zoom
echo '<script>
document.addEventListener("contextmenu", e => e.preventDefault());
document.addEventListener("selectstart", e => e.preventDefault());
document.addEventListener("keydown", function(e) {
  if ((e.ctrlKey && e.key === '+') || (e.ctrlKey && e.key === '-') || (e.ctrlKey && e.key === '0')) {
    e.preventDefault();
  }
});
</script>';

// Handle Add/Edit Category
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $image = $_FILES['image'];
    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;

    if ($image['name'] !== '') {
        $img_name = time() . '_' . basename($image['name']);
        move_uploaded_file($image['tmp_name'], '../images/' . $img_name);
    } else {
        $img_name = $_POST['old_image'] ?? '';
    }

    if ($id > 0) {
        $stmt = $conn->prepare("UPDATE categories SET name=?, image=? WHERE id=?");
        $stmt->bind_param("ssi", $name, $img_name, $id);
    } else {
        $stmt = $conn->prepare("INSERT INTO categories (name, image) VALUES (?, ?)");
        $stmt->bind_param("ss", $name, $img_name);
    }
    $stmt->execute();
    exit(json_encode(['success' => true]));
}

// Handle Delete Category
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM categories WHERE id=$id");
    header('Location: category.php');
    exit;
}

include('./common/header.php');
include('./common/sidebar.php');
?><main class="p-4 ml-16 select-none overflow-hidden">
  <h2 class="text-xl font-bold mb-4">Manage Categories</h2>
  <form id="categoryForm" enctype="multipart/form-data" class="mb-4 space-y-3">
    <input type="hidden" name="id" id="cat_id">
    <input type="hidden" name="old_image" id="old_image">
    <div>
      <input type="text" name="name" id="name" placeholder="Category Name" class="w-full border p-2 rounded focus:outline-none focus:ring">
    </div>
    <div>
      <input type="file" name="image" id="image" class="w-full">
    </div>
    <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Save</button>
  </form>  <div class="overflow-x-auto">
    <table class="min-w-full text-sm text-left border">
      <thead>
        <tr class="bg-gray-100">
          <th class="py-2 px-4 border">ID</th>
          <th class="py-2 px-4 border">Name</th>
          <th class="py-2 px-4 border">Image</th>
          <th class="py-2 px-4 border">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $result = $conn->query("SELECT * FROM categories ORDER BY id DESC");
        while ($row = $result->fetch_assoc()):
        ?>
        <tr class="border-t">
          <td class="py-2 px-4 border"><?php echo $row['id']; ?></td>
          <td class="py-2 px-4 border"><?php echo htmlspecialchars($row['name']); ?></td>
          <td class="py-2 px-4 border"><img src="../images/<?php echo htmlspecialchars($row['image']); ?>" alt="" class="w-12 h-12 object-cover rounded"></td>
          <td class="py-2 px-4 border space-x-2">
            <button onclick='editCategory(<?php echo json_encode($row); ?>)' class="text-blue-500 hover:underline">Edit</button>
            <a href="?delete=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure?')" class="text-red-500 hover:underline">Delete</a>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</main><script>
document.getElementById('categoryForm').onsubmit = function(e) {
  e.preventDefault();
  const formData = new FormData(this);
  fetch('category.php', {
    method: 'POST',
    body: formData
  })
  .then(res => res.json())
  .then(data => {
    if (data.success) {
      alert('Saved successfully!');
      location.reload();
    }
  });
};

function editCategory(cat) {
  document.getElementById('cat_id').value = cat.id;
  document.getElementById('name').value = cat.name;
  document.getElementById('old_image').value = cat.image;
}
</script><?php include('./common/bottom.php'); ?>