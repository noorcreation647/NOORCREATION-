<?php
include('common/config.php');
session_start();

// Initialize cart session if not already
if (!isset($_SESSION['cart'])) {
  $_SESSION['cart'] = [];
}

// Handle remove item
if (isset($_GET['remove'])) {
  $rid = $_GET['remove'];
  unset($_SESSION['cart'][$rid]);
  header("Location: cart.php");
  exit;
}

// Handle quantity update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_cart'])) {
  foreach ($_POST['qty'] as $pid => $qty) {
    if (isset($_SESSION['cart'][$pid])) {
      $_SESSION['cart'][$pid] = max(1, (int)$qty); // at least 1 qty
    }
  }
  header("Location: cart.php");
  exit;
}

// Fetch all product data from cart
$products = [];
$total = 0;

if (!empty($_SESSION['cart'])) {
  $ids = implode(',', array_keys($_SESSION['cart']));
  $result = $conn->query("SELECT * FROM products WHERE id IN ($ids)");
  while($row = $result->fetch_assoc()) {
    $pid = $row['id'];
    $qty = $_SESSION['cart'][$pid];
    $row['qty'] = $qty;
    $row['subtotal'] = $qty * $row['price'];
    $products[] = $row;
    $total += $row['subtotal'];
  }
}

include('common/header.php');
include('common/sidebar.php');
?>

<main class="p-4 pt-20 pb-20 select-none overflow-hidden">
  <h2 class="text-xl font-bold mb-4">Your Cart</h2>

  <?php if (!empty($products)): ?>
    <form method="POST">
      <div class="space-y-4">
        <?php foreach($products as $prod): ?>
          <div class="flex items-center space-x-4 border-b pb-4">
            <img src="uploads/<?= $prod['image'] ?>" class="w-20 h-20 object-cover rounded">
            <div class="flex-1">
              <h3 class="font-medium text-sm"><?= htmlspecialchars($prod['name']) ?></h3>
              <p class="text-red-600 font-bold">₹<?= number_format($prod['price']) ?></p>
              <input type="number" name="qty[<?= $prod['id'] ?>]" value="<?= $prod['qty'] ?>" min="1" class="border rounded w-16 text-center mt-1">
              <p class="text-xs text-gray-500 mt-1">Subtotal: ₹<?= number_format($prod['subtotal']) ?></p>
            </div>
            <a href="cart.php?remove=<?= $prod['id'] ?>" class="text-red-600 text-xs">Remove</a>
          </div>
        <?php endforeach; ?>
      </div>
      <div class="mt-6 text-right">
        <p class="font-bold text-lg">Total: ₹<?= number_format($total) ?></p>
        <div class="mt-4 space-x-2">
          <button type="submit" name="update_cart" class="bg-yellow-500 text-white px-4 py-2 rounded">Update</button>
          <a href="checkout.php" class="bg-green-600 text-white px-4 py-2 rounded">Checkout</a>
        </div>
      </div>
    </form>
  <?php else: ?>
    <p class="text-gray-500">Your cart is empty.</p>
  <?php endif; ?>
</main>

<?php include('common/bottom.php'); ?>

<script>
  document.addEventListener("contextmenu", e => e.preventDefault());
  document.addEventListener("selectstart", e => e.preventDefault());
  document.addEventListener("keydown", e => {
    if ((e.ctrlKey && ['+', '-', '0'].includes(e.key))) e.preventDefault();
  });
</script>