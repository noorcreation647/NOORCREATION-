<?php
include('common/config.php');
session_start();

$cat_id = $_GET['cat_id'] ?? null;

// Default heading
$cat_name = "All Products";

// If category is valid, fetch name
if ($cat_id) {
  $cat = $conn->query("SELECT name FROM categories WHERE id = $cat_id");
  if ($cat && $cat->num_rows > 0) {
    $cat_data = $cat->fetch_assoc();
    $cat_name = $cat_data['name'];
    $res = $conn->query("SELECT * FROM products WHERE category_id = $cat_id");
  } else {
    $res = $conn->query("SELECT * FROM products ORDER BY id DESC");
  }
} else {
  $res = $conn->query("SELECT * FROM products ORDER BY id DESC");
}

include('common/header.php');
include('common/sidebar.php');
?>

<main class="p-4 pt-20 pb-20 select-none overflow-hidden">
  <h2 class="text-xl font-bold mb-4"><?= htmlspecialchars($cat_name) ?></h2>

  <?php if ($res && $res->num_rows > 0): ?>
    <div class="grid grid-cols-2 gap-4">
      <?php while($row = $res->fetch_assoc()): ?>
        <div class="border rounded-lg p-2 shadow hover:shadow-md transition">
          <a href="product_detail.php?id=<?= $row['id'] ?>">
            <img src="uploads/<?= $row['image'] ?>" class="w-full h-32 object-cover rounded mb-2">
            <h3 class="text-sm font-medium"><?= htmlspecialchars($row['name']) ?></h3>
            <p class="text-red-600 font-bold">₹<?= number_format($row['price']) ?></p>
          </a>
          <button class="mt-1 text-xs bg-blue-600 text-white px-2 py-1 rounded">Add to Cart</button>
        </div>
      <?php endwhile; ?>
    </div>
  <?php else: ?>
    <p class="text-gray-500">No products found.</p>
  <?php endif; ?>
</main>

<?php include('common/bottom.php'); ?>

<script>
  document.addEventListener("contextmenu", e => e.preventDefault());
  document.addEventListener("selectstart", e => e.preventDefault());
  document.addEventListener("keydown", e => {
    if ((e.ctrlKey && ['+', '-', '0'].includes(e.key))) e.preventDefault();
  });
</script>