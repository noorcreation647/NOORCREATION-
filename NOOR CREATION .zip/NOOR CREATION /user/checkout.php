<?php
include('common/config.php');
session_start();

if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
  header("Location: cart.php");
  exit;
}

$user_id = $_SESSION['user_id'] ?? 0;

// Autofill user data if logged in
$user = ['name' => '', 'phone' => '', 'address' => ''];
if ($user_id) {
  $result = $conn->query("SELECT name, phone FROM users WHERE id = $user_id");
  if ($result && $result->num_rows > 0) {
    $user = $result->fetch_assoc();
    $user['address'] = ''; // manually enter address
  }
}

$success = false;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name = trim($_POST['name']);
  $phone = trim($_POST['phone']);
  $address = trim($_POST['address']);

  if ($name && $phone && $address) {
    // Insert order
    $total = 0;
    $items = [];

    $ids = implode(',', array_keys($_SESSION['cart']));
    $res = $conn->query("SELECT * FROM products WHERE id IN ($ids)");
    while ($row = $res->fetch_assoc()) {
      $qty = $_SESSION['cart'][$row['id']];
      $subtotal = $qty * $row['price'];
      $total += $subtotal;
      $items[] = ['id' => $row['id'], 'qty' => $qty, 'price' => $row['price']];
    }

    $stmt = $conn->prepare("INSERT INTO orders (user_id, total_amount, status, created_at) VALUES (?, ?, 'Placed', NOW())");
    $stmt->bind_param("id", $user_id, $total);
    $stmt->execute();
    $order_id = $conn->insert_id;

    foreach ($items as $item) {
      $conn->query("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES ($order_id, {$item['id']}, {$item['qty']}, {$item['price']})");
    }

    $_SESSION['cart'] = []; // clear cart
    header("Location: order.php?success=1");
    exit;
  } else {
    $error = "All fields are required.";
  }
}

include('common/header.php');
include('common/sidebar.php');
?>

<main class="p-4 pt-20 pb-20 select-none overflow-hidden">
  <h2 class="text-xl font-bold mb-4">Checkout</h2>

  <?php if ($error): ?>
    <p class="bg-red-100 text-red-700 p-2 rounded mb-4"><?= htmlspecialchars($error) ?></p>
  <?php endif; ?>

  <form method="POST" class="space-y-4">
    <div>
      <label class="block mb-1 font-medium">Name</label>
      <input type="text" name="name" value="<?= htmlspecialchars($user['name']) ?>" required class="w-full border p-2 rounded">
    </div>
    <div>
      <label class="block mb-1 font-medium">Phone</label>
      <input type="text" name="phone" value="<?= htmlspecialchars($user['phone']) ?>" required class="w-full border p-2 rounded">
    </div>
    <div>
      <label class="block mb-1 font-medium">Address</label>
      <textarea name="address" required class="w-full border p-2 rounded"><?= htmlspecialchars($user['address']) ?></textarea>
    </div>
    <p class="text-sm text-gray-600">Payment: <b>Cash on Delivery</b> only</p>
    <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded">Place Order</button>
  </form>
</main>

<?php include('common/bottom.php'); ?>

<script>
  document.addEventListener("contextmenu", e => e.preventDefault());
  document.addEventListener("selectstart", e => e.preventDefault());
  document.addEventListener("keydown", e => {
    if ((e.ctrlKey && ['+', '-', '0'].includes(e.key))) e.preventDefault();
  });
</script>