<?php
include('common/config.php');
session_start();

$id = isset($_GET['id']) && is_numeric($_GET['id']) ? $_GET['id'] : 0;

// Fetch main product
$product = $conn->query("SELECT * FROM products WHERE id = $id")->fetch_assoc();

if (!$product) {
  include('common/header.php');
  echo "<main class='pt-24 text-center text-red-600 text-xl font-semibold'>Product not found!</main>";
  exit;
}

// Fetch related products
$related = $conn->query("SELECT * FROM products WHERE category_id = {$product['category_id']} AND id != $id LIMIT 6");

include('common/header.php');
include('common/sidebar.php');
?>

<main class="p-4 pt-20 pb-20 select-none overflow-hidden">
  <!-- Image Slider -->
  <div class="relative mb-4">
    <img id="sliderImage" src="uploads/<?= htmlspecialchars($product['image']) ?>" class="w-full h-64 object-cover rounded shadow">
  </div>

  <!-- Product Info -->
  <h2 class="text-xl font-bold mb-1"><?= htmlspecialchars($product['name']) ?></h2>
  <p class="text-red-600 font-bold text-lg">₹<?= number_format($product['price']) ?></p>
  <p class="text-gray-600 mt-2"><?= nl2br(htmlspecialchars($product['description'])) ?></p>

  <div class="mt-4 flex items-center space-x-4">
    <label class="text-sm font-medium">Qty:</label>
    <input type="number" value="1" min="1" class="w-16 border rounded p-1 text-center">
  </div>

  <button class="mt-4 w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700">Add to Cart</button>

  <!-- Related Products -->
  <?php if ($related->num_rows > 0): ?>
    <h3 class="text-lg font-bold mt-10 mb-2">You may also like</h3>
    <div class="grid grid-cols-2 gap-4">
      <?php while($rel = $related->fetch_assoc()): ?>
        <a href="product_detail.php?id=<?= $rel['id'] ?>" class="block border rounded p-2 shadow">
          <img src="uploads/<?= htmlspecialchars($rel['image']) ?>" class="w-full h-24 object-cover rounded mb-2">
          <h4 class="text-sm font-medium"><?= htmlspecialchars($rel['name']) ?></h4>
          <p class="text-red-600 font-bold text-sm">₹<?= number_format($rel['price']) ?></p>
        </a>
      <?php endwhile; ?>
    </div>
  <?php endif; ?>
</main>

<?php include('common/bottom.php'); ?>

<script>
  document.addEventListener("contextmenu", e => e.preventDefault());
  document.addEventListener("selectstart", e => e.preventDefault());
  document.addEventListener("keydown", e => {
    if ((e.ctrlKey && ['+', '-', '0'].includes(e.key))) e.preventDefault();
  });
</script>
<?php
session_start();
include('../common/config.php');

// Fetching product details from database
$product_id = $_GET['id'] ?? '';
$product = $conn->query("SELECT * FROM products WHERE id = $product_id")->fetch_assoc();
?>

<!-- Product Details -->
<h1><?= $product['name']; ?></h1>
<p>Price: ₹<?= $product['price']; ?></p>
<p><?= $product['description']; ?></p>

<!-- Add to Cart Form -->
<form method="POST" action="add_to_cart.php">
    <input type="hidden" name="product_id" value="<?= $product['id']; ?>">
    <input type="number" name="quantity" value="1" min="1" required>
    <button type="submit">Add to Cart</button>
</form>
<a href="add_to_wishlist.php?product_id=<?php echo $product['id']; ?>">Add to Wishlist</a>