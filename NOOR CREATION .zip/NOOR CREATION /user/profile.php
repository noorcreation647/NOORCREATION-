<?php
include('common/config.php');
session_start();

$user_id = $_SESSION['user_id'] ?? 0;
if (!$user_id) {
  header("Location: login.php");
  exit;
}

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name = trim($_POST['name']);
  $phone = trim($_POST['phone']);
  $address = trim($_POST['address']);

  if ($name && $phone) {
    $stmt = $conn->prepare("UPDATE users SET name = ?, phone = ?, address = ? WHERE id = ?");
    $stmt->bind_param("sssi", $name, $phone, $address, $user_id);
    $stmt->execute();
    $success = "Profile updated!";
  } else {
    $error = "Name and phone are required.";
  }
}

if (isset($_POST['change_password'])) {
  $current = trim($_POST['current_password']);
  $new = trim($_POST['new_password']);

  $res = $conn->query("SELECT * FROM users WHERE id = $user_id AND password = '$current'");
  if ($res->num_rows == 1) {
    $conn->query("UPDATE users SET password = '$new' WHERE id = $user_id");
    $success = "Password changed!";
  } else {
    $error = "Incorrect current password.";
  }
}

$user = $conn->query("SELECT * FROM users WHERE id = $user_id")->fetch_assoc();

include('common/header.php');
include('common/sidebar.php');
?>

<main class="p-4 pt-20 pb-20 select-none overflow-hidden">
  <h2 class="text-xl font-bold mb-4">My Profile</h2>

  <?php if ($success): ?>
    <p class="bg-green-100 text-green-700 p-2 rounded mb-4"><?= $success ?></p>
  <?php elseif ($error): ?>
    <p class="bg-red-100 text-red-700 p-2 rounded mb-4"><?= $error ?></p>
  <?php endif; ?>

  <!-- Update Info -->
  <form method="POST" class="space-y-4">
    <div>
      <label class="block mb-1 font-medium">Name</label>
      <input type="text" name="name" value="<?= htmlspecialchars($user['name']) ?>" required class="w-full border p-2 rounded">
    </div>
    <div>
      <label class="block mb-1 font-medium">Phone</label>
      <input type="text" name="phone" value="<?= htmlspecialchars($user['phone']) ?>" required class="w-full border p-2 rounded">
    </div>
    <div>
      <label class="block mb-1 font-medium">Address</label>
      <textarea name="address" class="w-full border p-2 rounded"><?= htmlspecialchars($user['address']) ?></textarea>
    </div>
    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Update Profile</button>
  </form>

  <!-- Change Password -->
  <h3 class="text-lg font-bold mt-10">Change Password</h3>
  <form method="POST" class="space-y-4 mt-2">
    <input type="hidden" name="change_password" value="1">
    <div>
      <label class="block mb-1 font-medium">Current Password</label>
      <input type="password" name="current_password" required class="w-full border p-2 rounded">
    </div>
    <div>
      <label class="block mb-1 font-medium">New Password</label>
      <input type="password" name="new_password" required class="w-full border p-2 rounded">
    </div>
    <button type="submit" class="bg-yellow-600 text-white px-4 py-2 rounded">Change Password</button>
  </form>

  <a href="logout.php" class="block text-center text-red-600 mt-6 underline">Logout</a>
</main>

<?php include('common/bottom.php'); ?>

<script>
  document.addEventListener("contextmenu", e => e.preventDefault());
  document.addEventListener("selectstart", e => e.preventDefault());
  document.addEventListener("keydown", e => {
    if ((e.ctrlKey && ['+', '-', '0'].includes(e.key))) e.preventDefault();
  });
</script>