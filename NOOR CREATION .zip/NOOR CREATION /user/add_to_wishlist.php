<?php
session_start();
include('../common/config.php');

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

$user_email = $_SESSION['user'];
$user_result = mysqli_query($conn, "SELECT id FROM users WHERE email = '$user_email'");
$user_row = mysqli_fetch_assoc($user_result);
$user_id = $user_row['id'];

$product_id = intval($_GET['product_id']);

// Prevent duplicate wishlist
$check = mysqli_query($conn, "SELECT * FROM wishlist WHERE user_id=$user_id AND product_id=$product_id");
if (mysqli_num_rows($check) == 0) {
    mysqli_query($conn, "INSERT INTO wishlist(user_id, product_id) VALUES ($user_id, $product_id)");
}

header("Location: wishlist.php");
exit;