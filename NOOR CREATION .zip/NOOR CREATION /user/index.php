<?php
include('common/config.php');
session_start();

// Fetch categories
$cat_res = $conn->query("SELECT * FROM categories LIMIT 10");

// Fetch featured products
$prod_res = $conn->query("SELECT * FROM products ORDER BY id DESC LIMIT 12");

include('common/header.php');
include('common/sidebar.php');
?>

<main class="p-4 pt-20 pb-20 select-none overflow-hidden">
  <h2 class="text-lg font-bold mb-2">Top Categories</h2>
  <div class="flex space-x-4 overflow-x-auto mb-6">
    <?php while($cat = $cat_res->fetch_assoc()): ?>
      <a href="product.php?cat_id=<?= $cat['id'] ?>" class="flex-shrink-0 text-center">
        <img src="uploads/<?= $cat['image'] ?>" class="w-16 h-16 object-cover rounded-full border">
        <p class="text-sm mt-1"><?= htmlspecialchars($cat['name']) ?></p>
      </a>
    <?php endwhile; ?>
  </div>

  <h2 class="text-lg font-bold mb-2">Featured Products</h2>
  <div class="grid grid-cols-2 gap-4">
    <?php while($prod = $prod_res->fetch_assoc()): ?>
      <div class="border rounded-lg p-2 shadow hover:shadow-md transition">
        <a href="product_detail.php?id=<?= $prod['id'] ?>">
          <img src="uploads/<?= $prod['image'] ?>" class="w-full h-32 object-cover rounded mb-2">
          <h3 class="text-sm font-medium"><?= htmlspecialchars($prod['name']) ?></h3>
          <p class="text-red-600 font-bold">₹<?= number_format($prod['price']) ?></p>
        </a>
        <button class="mt-1 text-xs bg-blue-600 text-white px-2 py-1 rounded">Add to Cart</