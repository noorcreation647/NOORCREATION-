<?php
include('common/config.php');
session_start();

$user_id = $_SESSION['user_id'] ?? 0;
if (!$user_id) {
  header("Location: login.php");
  exit;
}

$orders = $conn->query("SELECT * FROM orders WHERE user_id = $user_id ORDER BY id DESC");

include('common/header.php');
include('common/sidebar.php');
?>

<main class="p-4 pt-20 pb-20 select-none overflow-hidden">
  <h2 class="text-xl font-bold mb-4">Your Orders</h2>

  <?php if (isset($_GET['success'])): ?>
    <p class="bg-green-100 text-green-700 p-2 rounded mb-4">Order placed successfully!</p>
  <?php endif; ?>

  <div class="flex mb-4 space-x-2">
    <button onclick="showTab('active')" class="tab-btn bg-blue-600 text-white px-4 py-2 rounded">Active</button>
    <button onclick="showTab('history')" class="tab-btn bg-gray-200 text-black px-4 py-2 rounded">History</button>
  </div>

  <div id="active-tab">
    <?php
    $orders->data_seek(0);
    $found = false;
    while ($o = $orders->fetch_assoc()):
      if (in_array($o['status'], ['Placed', 'Dispatched'])):
        $found = true;
        $items = $conn->query("SELECT p.name, p.image, oi.quantity, oi.price FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE order_id = {$o['id']}");
    ?>
    <div class="border p-4 rounded mb-4 shadow">
      <div class="flex justify-between">
        <p class="font-medium">Order #<?= $o['id'] ?> — ₹<?= number_format($o['total_amount']) ?></p>
        <span class="text-sm text-blue-700"><?= $o['status'] ?></span>
      </div>

      <div class="flex items-center mt-2 space-x-2 overflow-x-auto">
        <?php while ($i = $items->fetch_assoc()): ?>
          <img src="uploads/<?= $i['image'] ?>" class="w-16 h-16 object-cover rounded">
        <?php endwhile; ?>
      </div>

      <!-- Status Tracker -->
      <div class="flex items-center mt-4 text-xs font-medium">
        <div class="flex-1 text-center <?= $o['status'] !== 'Placed' ? 'text-green-600' : 'text-black' ?>">
          <i class="fas fa-check-circle"></i><br>Placed
        </div>
        <div class="flex-1 text-center <?= $o['status'] === 'Dispatched' || $o['status'] === 'Delivered' ? 'text-green-600' : 'text-black' ?>">
          <i class="fas fa-truck"></i><br>Dispatched
        </div>
        <div class="flex-1 text-center <?= $o['status'] === 'Delivered' ? 'text-green-600' : 'text-black' ?>">
          <i class="fas fa-box"></i><br>Delivered
        </div>
      </div>
    </div>
    <?php endif; endwhile; if (!$found): ?>
      <p class="text-gray-500">No active orders.</p>
    <?php endif; ?>
  </div>

  <div id="history-tab" class="hidden">
    <?php
    $orders->data_seek(0);
    $found = false;
    while ($o = $orders->fetch_assoc()):
      if (in_array($o['status'], ['Delivered', 'Cancelled'])):
        $found = true;
        $items = $conn->query("SELECT p.name, p.image, oi.quantity, oi.price FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE order_id = {$o['id']}");
    ?>
    <div class="border p-4 rounded mb-4 shadow">
      <div class="flex justify-between">
        <p class="font-medium">Order #<?= $o['id'] ?> — ₹<?= number_format($o['total_amount']) ?></p>
        <span class="text-sm text-green-700"><?= $o['status'] ?></span>
      </div>

      <div class="grid grid-cols-2 gap-2 mt-2">
        <?php while ($i = $items->fetch_assoc()): ?>
          <div class="flex space-x-2">
            <img src="uploads/<?= $i['image'] ?>" class="w-12 h-12 object-cover rounded">
            <div>
              <p class="text-sm"><?= htmlspecialchars($i['name']) ?></p>
              <p class="text-xs text-gray-500">Qty: <?= $i['quantity'] ?> | ₹<?= number_format($i['price']) ?></p>
            </div>
          </div>
        <?php endwhile; ?>
      </div>
    </div>
    <?php endif; endwhile; if (!$found): ?>
      <p class="text-gray-500">No order history.</p>
    <?php endif; ?>
  </div>
</main>

<?php include('common/bottom.php'); ?>

<script>
  function showTab(tab) {
    document.getElementById('active-tab').classList.add('hidden');
    document.getElementById('history-tab').classList.add('hidden');
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('bg-blue-600', 'text-white'));
    if (tab === 'active') {
      document.getElementById('active-tab').classList.remove('hidden');
      document.querySelectorAll('.tab-btn')[0].classList.add('bg-blue-600', 'text-white');
    } else {
      document.getElementById('history-tab').classList.remove('hidden');
      document.querySelectorAll('.tab-btn')[1].classList.add('bg-blue-600', 'text-white');
    }
  }

  // Disable zoom/select
  document.addEventListener("contextmenu", e => e.preventDefault());
  document.addEventListener("selectstart", e => e.preventDefault());
  document.addEventListener("keydown", e => {
    if ((e.ctrlKey && ['+', '-', '0'].includes(e.key))) e.preventDefault();
  });
</script>