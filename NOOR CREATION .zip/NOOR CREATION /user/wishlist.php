<?php
session_start();
include('../common/config.php');

// Check login
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

// Get user info
$user_email = $_SESSION['user'];
$user_result = mysqli_query($conn, "SELECT id FROM users WHERE email = '$user_email'");
$user_row = mysqli_fetch_assoc($user_result);
$user_id = $user_row['id'];

// Fetch wishlist products
$sql = "SELECT p.* FROM wishlist w 
        JOIN products p ON w.product_id = p.id 
        WHERE w.user_id = $user_id";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Wishlist</title>
</head>
<body>
    <h2>Your Wishlist</h2>
    <?php while($row = mysqli_fetch_assoc($result)): ?>
        <div>
            <h3><?php echo $row['name']; ?></h3>
            <p>Price: ₹<?php echo $row['price']; ?></p>
            <a href="product_detail.php?id=<?php echo $row['id']; ?>">View Product</a>
        </div>
        <hr>
    <?php endwhile; ?>
</body>
</html>