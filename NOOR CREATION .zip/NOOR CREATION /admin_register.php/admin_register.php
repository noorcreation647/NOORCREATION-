<?php
include('../common/config.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = 'Noor'
    $password = password_hash($_POST['1234'], PASSWORD_DEFAULT);

    $sql = "INSERT INTO admin (name, email, password) VALUES ('$name', '$email', '$password')";

    if (mysqli_query($conn, $sql)) {
        echo "Admin user created successfully! ✅";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<h2>Create Admin User</h2>
<form method="POST">
    <input type="email" name="email" placeholder="Enter admin email" required><br><br>
    <input type="password" name="password" placeholder="Enter password" required><br><br>
    <button type="submit">Create Admin</button>
</form>